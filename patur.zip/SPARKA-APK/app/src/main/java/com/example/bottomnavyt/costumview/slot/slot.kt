package com.example.bottomnavyt.costumview.slot

data class slot(
    val id: Int?,
    var x: Float? = 0F,
    var y: Float? = 0F,
    var name: String,
    var isBooked: Boolean
)
