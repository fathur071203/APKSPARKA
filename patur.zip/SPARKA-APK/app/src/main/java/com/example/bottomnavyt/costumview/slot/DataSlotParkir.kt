package com.example.bottomnavyt.costumview.slot

class DataSlotParkir {

}