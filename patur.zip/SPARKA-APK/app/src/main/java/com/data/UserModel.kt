package com.data

class UserModel(
    val token: String,
    val expiredTime: Int,
    val isLogin: Boolean
)